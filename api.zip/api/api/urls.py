

from django.urls import path
from predictor import views

urlpatterns = [
    path('classify_obesity/', views.call_model.as_view())
]
