from django.shortcuts import render
from .apps import PredictorConfig
from django.http import JsonResponse
from rest_framework.views import APIView
import pandas as pd

class call_model(APIView):
    def get(self,request):
        if request.method == 'GET':            # get sound from request
            Gender = request.GET.get('Gender')
            Age = request.GET.get('Age')
            Height = request.GET.get('Height')
            Weight = request.GET.get('Weight')
            genetic= request.GET.get('genetic')
            high_calorific = request.GET.get('high_calorific')
            vegetable=request.GET.get('vegetable')
            frequence_meal = request.GET.get('frequence_meal')
            between_meal = request.GET.get('between_meal')
            water = request.GET.get('water')
            physical_activity = request.GET.get('physical_activity')
            technology_time = request.GET.get('technology_time')
            alcohol = request.GET.get('alcohol')
            transportation = request.GET.get('transportation')
   
            # vectorize sound
            
            Data=pd.DataFrame([[Gender,Age,Height,Weight,genetic,high_calorific,vegetable,frequence_meal,between_meal,water,physical_activity,technology_time,alcohol,transportation]],columns=['Gender','Age','Height','Weight','genetic','high_calorific','vegetable','frequence_meal','between_meal','water','physical_activity','technology_time','alcohol','transportation'])
            
            
            vector = PredictorConfig.transformer.transform(Data)            # predict based on vector
            prediction = PredictorConfig.model.predict(vector)[0]            # build response
            response = {'Obesity': prediction}            # return response
            return JsonResponse(response)
        
        
